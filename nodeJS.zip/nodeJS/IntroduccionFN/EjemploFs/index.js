//FS y ejemplo asincrono
const fs = require('fs');

fs.writeFile('./text.txt', 'Contenido del texto papa v2', (err)=>{
    if(err){
        console.log(err);
    }
    console.log("archivo creado!");
});

console.log("Ultima linea del Write");


fs.readFile('./text.txt', (err, data)=>{

    if(err){
        console.log(err);
    }
    if(data){
        console.log(data.toString());
    }
});

console.log("Ultima linea del Read");

/*
//////EJEMPLO BASE DE DATOS
////Blocked
const users = QUERY('Select * FROM Users');

////Async
query('Select * FROM Users', (err, users) => {

    if(err){
        console.log(err);
    }

    if(users){
        console.log(users);
    }

} );
*/


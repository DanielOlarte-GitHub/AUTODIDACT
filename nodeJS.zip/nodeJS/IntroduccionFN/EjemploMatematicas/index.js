const math = require('./math.js');

console.log(math.sumar(1,3));
console.log(math.restar(1,3));
console.log(math.dividir(1,3));
console.log(math.multiplicar(1,3));
console.log(math.dividir(1,0));

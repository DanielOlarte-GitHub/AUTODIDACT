const os = require('os')

console.log(os.platform());
console.log(os.release());
console.log('memoria libre', os.freemem(), 'bytes');
console.log('Total de memoria ',os.totalmem(), 'bytes');
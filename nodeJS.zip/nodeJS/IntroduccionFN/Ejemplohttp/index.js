//PRIMERO
//TERMINADO
const http = require('http');

const servidor = 3000;

http.createServer((req, res)=>{
    res.writeHead(200, {'Content-type': 'text/html'})
    res.write('<h1>HOLA MUNDO DESDE NODEJS</h1>');
    res.end();
}).listen(servidor, ()=>{
    console.log("Servidor en el puerto: ",servidor);
});
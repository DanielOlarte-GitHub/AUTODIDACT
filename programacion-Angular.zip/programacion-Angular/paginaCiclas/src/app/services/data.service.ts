import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { publicacion } from 'src/app/interfaces/publicaciones';

@Injectable({
  providedIn: 'root'
})
export class DataService {

  constructor(private link: HttpClient) {
    
   }

   getData(){
    return this.link.get<publicacion[]>("https://jsonplaceholder.typicode.com/posts");  
   }

}

import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  
  //funcion de el boton menu para mobile
  accion(){
    var ancla = document.getElementsByClassName("navegador-ancla");
    for (var i = 0; i < ancla.length; i++) {
      ancla[i].classList.toggle("desaparece");
    }

  }
}
 
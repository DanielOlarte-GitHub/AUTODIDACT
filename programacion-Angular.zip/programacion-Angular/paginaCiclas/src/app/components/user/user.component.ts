 import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.scss']
})
export class UserComponent implements OnInit {
 
  publicaciones = [];

  constructor() { 
  }

  ngOnInit(): void {
  } 
 
  //Nuevo
  users: string[] = ["daniel", "bryan", "juank"];   
  name:string = "John Carter";
  age:number = 18;

  deleteUser(usuario:string){
    for(let i=0; i<this.users.length; i++){
      if(usuario==this.users[i]){
        this.users.splice(i,1);
      }
    }
  }

  addUser(nuevoUsuario){
    this.users.push(nuevoUsuario.value);
    nuevoUsuario.value="";
    nuevoUsuario.focus();
    return false;
  }


  
}

import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { RouterModule, Route} from '@angular/router';

//Componentes
import { AppComponent } from './components/app/app.component';
import { UserComponent } from './components/user/user.component';
import { AboutComponent } from './components/about/about.component';

//Servicios
import { DataService } from './services/data.service';
import { ProgramsComponent } from './components/programs/programs.component';
import { ContactsComponent } from './components/contacts/contacts.component';

const rutas: Route[] = [
  {path: '', component: UserComponent},
  {path: 'about', component: AboutComponent},
  {path: 'programs', component: ProgramsComponent},
  {path: 'contacts', component: ContactsComponent}
]

@NgModule({
  declarations: [
    AppComponent,
    UserComponent,
    AboutComponent,
    ProgramsComponent,
    ContactsComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    RouterModule.forRoot(rutas)
  ],
  providers: [DataService],
  bootstrap: [AppComponent]
})
export class AppModule { }

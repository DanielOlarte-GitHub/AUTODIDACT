export interface publicacion{
    userId: Number;
    id: number;
    title: string;
    body: string;
}
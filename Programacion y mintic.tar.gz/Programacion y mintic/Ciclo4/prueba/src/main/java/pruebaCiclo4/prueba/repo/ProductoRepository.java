package pruebaCiclo4.prueba.repo;

import org.springframework.data.mongodb.repository.MongoRepository;
import pruebaCiclo4.prueba.model.Producto;

public interface ProductoRepository extends MongoRepository<Producto, String> {
}

package pruebaCiclo4.prueba.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import pruebaCiclo4.prueba.model.Producto;
import pruebaCiclo4.prueba.repo.ProductoRepository;

import java.util.List;
import java.util.Optional;

@Service
public class ProductoService {

    @Autowired
    private ProductoRepository productoRepository;

    public List<Producto> findAll(){
        return productoRepository.findAll();
    }

    public Producto save(Producto p){
        return productoRepository.save(p);
    }

    public Producto update (String id, Producto p){
        Producto p2 = productoRepository.findById(id).orElseThrow(RuntimeException::new);
        p2.setNombre(p.getNombre());
        p2.setDescripcion(p.getDescripcion());
        return productoRepository.save(p2);
    }

    public void delete(String id){
        Producto p2 = productoRepository.findById(id).orElseThrow(RuntimeException::new);
        productoRepository.delete(p2);
    }
}

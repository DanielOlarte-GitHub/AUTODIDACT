package pruebaCiclo4.prueba.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import pruebaCiclo4.prueba.model.Producto;
import pruebaCiclo4.prueba.service.ProductoService;

import java.util.List;

@CrossOrigin
@RestController
@RequestMapping("/productos")
public class ProductoController {

    @Autowired
    private ProductoService productoService;

    @GetMapping("")
    public List<Producto> index(){
        return productoService.findAll();
    }


    @ResponseStatus(HttpStatus.CREATED)
    @PostMapping("")
    public Producto create(@RequestBody Producto p){
        return productoService.save(p);
    }

    @ResponseStatus(HttpStatus.CREATED)
    @PutMapping("{id}")
    public Producto update(@PathVariable String id, @RequestBody Producto p){

        return productoService.update(id, p);
    }

    @DeleteMapping("{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable String id){
        productoService.delete(id);
    }
}

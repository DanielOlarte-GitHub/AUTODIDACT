//buscaminas
import java.util.Scanner;
import java.util.Random;
import java.util.Arrays;

public class buscaminas {


    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Random r = new Random();
        int filas = 0;
        int columnas = 0;
        int minas = 0;

        System.out.println("Introduce el número de filas: ");
        filas = sc.nextInt();
        System.out.println("Introduce el número de columnas: ");
        columnas = sc.nextInt();
        System.out.println("Introduce el número de minas: ");
        minas = sc.nextInt();
        int[][] tablero = new int[filas][columnas];

        for (int i = 0; i < filas; i++) {
            for (int j = 0; j < columnas; j++) {
                tablero[i][j] = 0;
            }
        }
        for (int i = 0; i < minas; i++) {
            int fila = r.nextInt(filas);
            int columna = r.nextInt(columnas);
            if (tablero[fila][columna] == 0) {
                tablero[fila][columna] = -1;
            } else {
                i--;
            }
        }
        for (int i = 0; i < filas; i++) {
            for (int j = 0; j < columnas; j++) {
                if (tablero[i][j] == 0) {
                    int minasAlrededor = 0;
                    for (int k = i - 1; k <= i + 1; k++) {
                        for (int l = j - 1; l <= j + 1; l++) {
                            if (k >= 0 && k < filas && l >= 0 && l < columnas) {
                                if (tablero[k][l] == -1) {
                                    minasAlrededor++;
                                }
                            }
                        }
                    }
                    tablero[i][j] = minasAlrededor;
                }
            }
        }
        for (int i = 0; i < filas; i++) {
            for (int j = 0; j < columnas; j++) {
                System.out.print(tablero[i][j] + " ");
            }
            System.out.println();
        }
        int fila = 0;
        int columna = 0;
        boolean ganador = false;
        while (!ganador) {
            System.out.println("Introduce la fila: ");
            fila = sc.nextInt();
            System.out.println("Introduce la columna: ");
            columna = sc.nextInt();
            if (tablero[fila][columna] == -1) {
                System.out.println("Has perdido");
                ganador = true;
            } else {
                System.out.println("Has encontrado una mina");
            }

        }
    }
}








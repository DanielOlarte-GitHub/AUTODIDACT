const employeesCtrl = {};

const Employee = require('../models/employee')

employeesCtrl.getEmployees = async (req,res) => {
    const employees = await Employee.find() 
    res.json(employees)
}

employeesCtrl.createEmployees = (req,res) => {
    res.send("createEmployees");
}

employeesCtrl.getEmployee = (req,res) => {
    res.send("getEmployee");
}

employeesCtrl.editEmployees = (req,res) => {
    res.send("editEmployees");
}

employeesCtrl.deleteEmployees = (req,res) => {
        res.send("deleteEmployees");
}

module.exports = employeesCtrl;
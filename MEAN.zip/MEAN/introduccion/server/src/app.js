const express = require('express');
const morgan = require('morgan');
const routes = require('./routes/employees.routes');

const app = express();

//CONFIGURACION
app.set('port', process.env.PORT || 5000);

//MIDDLEWARES
app.use(morgan('dev'));
app.use('/api/employees', routes);



module.exports = app;
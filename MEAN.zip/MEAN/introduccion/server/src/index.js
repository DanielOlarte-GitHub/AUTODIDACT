require ('./database');
const app = require('./app');

app.listen(app.get('port'));
console.log("El server esta en el puerto ", app.get('port'));
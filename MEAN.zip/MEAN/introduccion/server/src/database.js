const moongose = require('mongoose');

moongose
    .connect('mongodb://localhost/mean-employees', {
        useUnifiedTopology: true,
        useNewUrlParser: true   
        
    })
    .then((db)=> console.log('Esta conectada'))
    .catch((err) => console.error(err));
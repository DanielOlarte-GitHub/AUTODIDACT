//SEGUNDO
//TERMINADO
const express = require('express');
const app = express();
const morgan = require('morgan'); 

//SETTINGS (Variable y Valor)
app.set('NombreApp', 'Introduccion Express');
app.set('Puerto', 3000); 
//app.set('Motor Plantilla', 'ejs');


//MIDDLEWARES
/* EJEMPLO DE MORGAN MANUAL
function logger(req,res,next){
    console.log(`Ruta recibida: ${req.protocol} ://${req.get('host')}${req.originalUrl}`);
    next();
}*/
 
app.use(express.json());
app.use(morgan('dev'));
//app.use(logger);

//ROUTES
app.all('/user/:id', (req, res, next)=>{
    console.log("Pasandooo....");
    next();
});

app.get('/', (req,res)=>{
    const datos = [{nombre: 'Jhon'}, {nombre: 'joe'}, {nombre: 'Cameron'}, {nombre: 'Daniel'}]
    res.render('index.ejs', {personas: datos});
});

app.get('/user', (req,res)=>{
    res.json({
        nombre: "Daniel Olarte",
        edad: "18",
        deporte: "Futbol"
    });
});

app.post('/user/:id', (req,res)=>{
    console.log(req.body);
    console.log(req.params);
    res.send(`<h1>PETICION POST RECIBIDA ID: ${req.params.id}</h1>`)
});

app.put('/user/:id', (req, res)=>{
    console.log(req.body);
    res.send(`Usuario ${req.params.id} Ha sido actualizado`)
});

app.delete('/user/:id', (req, res)=>{

    res.send(`User ${req.params.id} Ha sido eliminado`);
});

//Solo en la ruta principal si no hay nada definido
app.use(express.static('public'));

app.listen(app.get('Puerto'), ()=>{
    console.log(app.get('NombreApp'));
    console.log("Servidor en el puerto: ",app.get('Puerto'));
});


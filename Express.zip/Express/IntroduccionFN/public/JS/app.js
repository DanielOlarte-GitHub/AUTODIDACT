setTimeout(()=>{
    document.getElementById("titulo").innerHTML="Cambio de titulo";
},2000);
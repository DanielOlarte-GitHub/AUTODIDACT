//Rutas
const express = require('express');
const router = express.Router();

router.get('/', (req,res)=>{
    //res.render('index.html', {title: "PROQUINAL SPRADLING"});
    res.render('index.html', {title: "Pagina Express"});
});

router.get('/contact', (req,res)=>{
    //res.render('contact.html', {title: "PROQUINAL SPRADLING"});
    res.render('contact.html', {title: "Pagina Express"});
});

router.get('/about', (req, res)=>{
    res.send("Pagina About");
});

module.exports = router;
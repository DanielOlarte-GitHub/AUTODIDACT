//TERCERO
//FINALIZADO
const express = require('express');
const app = express();
const morgan = require('morgan');
const path = require('path');

//Configuracion
app.set("puerto",3000);
app.set("views", path.join(__dirname,'views'));
app.engine('html',require('ejs').renderFile);
app.set("view engine", "ejs");


//Middlewares


//Rutas
app.use(require('./routes'));


//Archivos Estaticos
app.use(express.static(path.join(__dirname,'public')))

//Listening
app.listen(app.get("puerto"), ()=>{
    console.log(`Servidor iniciado en el puerto ${app.get("puerto")}`);
});
package com.example.ciclo3.Reto3.repository.crud;

import org.springframework.data.repository.CrudRepository;

import com.example.ciclo3.Reto3.model.Category;

public interface CrudRepositoryCategory extends CrudRepository<Category,Integer>{

    
}
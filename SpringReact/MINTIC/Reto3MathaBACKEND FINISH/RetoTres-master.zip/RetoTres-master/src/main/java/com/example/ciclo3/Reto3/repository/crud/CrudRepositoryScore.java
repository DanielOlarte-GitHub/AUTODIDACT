package com.example.ciclo3.Reto3.repository.crud;

import org.springframework.data.repository.CrudRepository;

import com.example.ciclo3.Reto3.model.Score;

public interface CrudRepositoryScore extends CrudRepository<Score,Integer> {
    
}
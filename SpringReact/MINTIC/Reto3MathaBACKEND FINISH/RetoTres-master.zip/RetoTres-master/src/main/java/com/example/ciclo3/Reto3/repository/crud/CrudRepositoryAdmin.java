package com.example.ciclo3.Reto3.repository.crud;

import org.springframework.data.repository.CrudRepository;
import com.example.ciclo3.Reto3.model.Admin;

public interface CrudRepositoryAdmin extends CrudRepository<Admin,Integer> {

    
}
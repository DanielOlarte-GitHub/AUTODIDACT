package com.example.ciclo3.Reto3.repository.crud;

import org.springframework.data.repository.CrudRepository;

import com.example.ciclo3.Reto3.model.Reservation;

public interface CrudRepositoryReservation  extends CrudRepository<Reservation,Integer>{
    
}